document.addEventListener('DOMContentLoaded', function() {
    // Header Sticky
    const $headerSticky = document.querySelector(".header__sticky");
    const $mainNavigation = document.querySelector(".main-navigation");

    window.addEventListener("scroll", function() {
        if ($mainNavigation) {
            const { top } = $mainNavigation.getBoundingClientRect();
            
            if (top + window.scrollY < 250) {
                if ($headerSticky.classList.contains("is-active")) $headerSticky.classList.remove("is-active");
            } else {
                if (!$headerSticky.classList.contains("is-active")) $headerSticky.classList.add("is-active");
            }
        }
    });
    // .Header Sticky

    // Search
    const $searchInput = document.querySelector(".search #search");
    $searchInput.setAttribute("placeholder", "Search...");
    // .Search

    // Filter Options
    const $filterOptions = document.querySelectorAll('.filter-options');

    $filterOptions.forEach(function(filterOption) {
        const $optionsTitles = filterOption.querySelectorAll('.filter-options-title');

        $optionsTitles.forEach(function(optionsTitle) {
            optionsTitle.classList.remove('active');
            optionsTitle.nextElementSibling.classList.remove('active');

            optionsTitle.addEventListener('click', function() {
                optionsTitle.classList.toggle('active');
                optionsTitle.nextElementSibling.classList.toggle('active');
            });
        });
    });
    // .Filter Options

    // Quantity
    const $quantityControls = document.querySelectorAll('.quantity__control');
    $quantityControls.forEach(function(quantityControl) {
        const $decrement = quantityControl.querySelector('.decrement');
        const $input = quantityControl.querySelector('.quantity__input');
        const $increment = quantityControl.querySelector('.increment');

        $decrement.addEventListener('click', function() {
            if ($input.value > 1) {
                $input.value = $input.value - 1;
            }
        });

        $increment.addEventListener('click', function() {
            $input.value ++;
        });
    });
    // .Quantity
});