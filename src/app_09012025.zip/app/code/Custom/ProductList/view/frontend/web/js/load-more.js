/*
define(['jquery'], function($) {
    'use strict';

    return function(config) {
        let page = 1;
        const $button = $('#load-more');
        const $container = $(config.container)

        if (!$button) return;

        $button.on('click', function(){
            page++;

            $.ajax({
                url: config.url,
                type: 'GET',
                dataType: 'json',
                data: {
                    page: page
                }
            }).done(function(response){
                if (response.html) {
                    $container.append(response.html);
                }

                if (!response.has_more) {
                    $button.hide();
                }
            });
        });
    };
});
*/

define([], function() {
    'use strict';

    return function(config) {
        let page = 1;
        const $container        = document.querySelector('.product-list');
        const $loadMoreButton   = document.querySelector('.product-list__load-more');
        const $toolbarAmount    = document.querySelector('.toolbar__amount');
        const $toolbarOrder     = document.querySelector('.toolbar__order');
        const $toolbarDirection = document.querySelector('.toolbar__direction');

        let directionValue = 'asc';

        if (!$loadMoreButton) return;

        const fetchData = function() {
            const URL_TO_FETCH = `${config.url}?current_page=${page}&category_id=${config.category_id}&order=${$toolbarOrder.value}&direction=${directionValue}`;

            fetch(URL_TO_FETCH)
                .then(function(response) {
                    return response.json();
                })
                .then(function(data) {
                    console.log(data)
                    $container.insertAdjacentHTML('beforeend', data.html);
                    $loadMoreButton.innerHTML = 'Load More';
                    if (page === 1) $toolbarAmount.innerHTML = `${data.total} items`;

                    if (!data.has_more) {
                        // button.style.display = 'none';
                    }
                });
        };

        fetchData();

        $loadMoreButton.addEventListener('click', function(){
            $loadMoreButton.innerHTML = 'Loading...';
            page++;
            fetchData();
        });

        $toolbarOrder.addEventListener('change', function() {
            $container.innerHTML = "";
            fetchData();
        });
        
        $toolbarDirection.addEventListener('click', function() {
            $container.innerHTML = "";
            $toolbarDirection.classList.toggle('desc');
            
            directionValue = (directionValue === 'desc') ? 'asc' : 'desc';
            
            fetchData();
        });
    }
});